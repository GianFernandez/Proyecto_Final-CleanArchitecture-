﻿namespace App.Core.Entities
{
    public class DataTime
    {
    }
}